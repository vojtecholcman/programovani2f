/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lekce203;

/**
 *
 * @author vojtech.holcman.s
 */
public interface MyInterface{
    void m1();
    public int m2();
    abstract int m3();
}