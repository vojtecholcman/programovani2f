/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lekce201;

import java.util.Calendar;

/**
 *
 * @author vojtech.holcman.s
 */
public class CalendarTest {
    public static void main(String[] args) {
        Calendar cal = Calendar.getInstance();
        //System.out.println(cal.set(Calendar.DAY_OF_MONTH, 20));
    }
}
